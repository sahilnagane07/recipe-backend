
  # Recipe Media App

  This is a code bundle for Recipe Media App. The original project is available at https://www.figma.com/design/cebvKF38nB5Pjjf84PuLTU/Recipe-Media-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  