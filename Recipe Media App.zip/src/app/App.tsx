import { useEffect, useState } from "react";
import { toast, Toaster } from "sonner";
import {
  User,
  Recipe,
  Comment,
  categories,
  initialUsers,
  initialRecipes,
  initialComments,
  loadFromLocalStorage,
  saveToLocalStorage,
} from "./data";
import Login from "./components/Login";
import Register from "./components/Register";
import Navbar from "./components/Navbar";
import Explore from "./components/Explore";
import AddRecipe from "./components/AddRecipe";
import MyRecipes from "./components/MyRecipes";

type AuthView = "login" | "register";
type AppView = "explore" | "add-recipe" | "my-recipes";

export default function App() {
  const [authView, setAuthView] = useState<AuthView>("login");
  const [currentView, setCurrentView] = useState<AppView>("explore");
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [comments, setComments] = useState<Comment[]>([]);

  useEffect(() => {
    const storedUsers = loadFromLocalStorage<User[]>("recipeapp_users", initialUsers);
    const storedRecipes = loadFromLocalStorage<Recipe[]>("recipeapp_recipes", initialRecipes);
    const storedComments = loadFromLocalStorage<Comment[]>("recipeapp_comments", initialComments);
    const storedCurrentUser = loadFromLocalStorage<User | null>("recipeapp_currentUser", null);

    setUsers(storedUsers);
    setRecipes(storedRecipes);
    setComments(storedComments);
    setCurrentUser(storedCurrentUser);
  }, []);

  useEffect(() => {
    saveToLocalStorage("recipeapp_users", users);
  }, [users]);

  useEffect(() => {
    saveToLocalStorage("recipeapp_recipes", recipes);
  }, [recipes]);

  useEffect(() => {
    saveToLocalStorage("recipeapp_comments", comments);
  }, [comments]);

  useEffect(() => {
    saveToLocalStorage("recipeapp_currentUser", currentUser);
  }, [currentUser]);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    toast.success(`Welcome back, ${user.fullName}!`);
  };

  const handleRegister = (newUser: User) => {
    const updatedUsers = [...users, newUser];
    setUsers(updatedUsers);
    setCurrentUser(newUser);
    setAuthView("login");
    toast.success("Account created successfully! You're now logged in.");
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentView("explore");
    toast.info("You've been logged out");
  };

  const handleAddRecipe = (recipeData: {
    title: string;
    ingredients: string;
    instructions: string;
    categoryId: number;
    imageUrl: string;
  }) => {
    if (!currentUser) return;

    const newRecipe: Recipe = {
      id: Math.max(...recipes.map((r) => r.id), 0) + 1,
      ...recipeData,
      userId: currentUser.id,
      createdAt: new Date().toISOString(),
    };

    setRecipes([newRecipe, ...recipes]);
    toast.success("Recipe published successfully!");
  };

  const handleAddComment = (recipeId: number, content: string) => {
    if (!currentUser) return;

    const newComment: Comment = {
      id: Math.max(...comments.map((c) => c.id), 0) + 1,
      recipeId,
      userId: currentUser.id,
      content,
      createdAt: new Date().toISOString(),
    };

    setComments([...comments, newComment]);
    toast.success("Comment added!");
  };

  const handleNavigate = (view: AppView) => {
    setCurrentView(view);
  };

  const handleRecipeSuccess = () => {
    setCurrentView("my-recipes");
  };

  if (!currentUser) {
    if (authView === "login") {
      return (
        <>
          <Login
            onLogin={handleLogin}
            onSwitchToRegister={() => setAuthView("register")}
            users={users}
          />
          <Toaster position="top-right" richColors />
        </>
      );
    } else {
      return (
        <>
          <Register
            onRegister={handleRegister}
            onSwitchToLogin={() => setAuthView("login")}
            users={users}
          />
          <Toaster position="top-right" richColors />
        </>
      );
    }
  }

  return (
    <div className="min-h-screen bg-background" style={{ fontFamily: 'DM Sans, sans-serif' }}>
      <Navbar
        currentUser={currentUser}
        onLogout={handleLogout}
        currentView={currentView}
        onNavigate={handleNavigate}
      />

      {currentView === "explore" && (
        <Explore
          recipes={recipes}
          users={users}
          categories={categories}
          comments={comments}
          currentUser={currentUser}
          onAddComment={handleAddComment}
        />
      )}

      {currentView === "add-recipe" && (
        <AddRecipe
          categories={categories}
          currentUser={currentUser}
          onAddRecipe={handleAddRecipe}
          onSuccess={handleRecipeSuccess}
        />
      )}

      {currentView === "my-recipes" && (
        <MyRecipes
          recipes={recipes}
          users={users}
          categories={categories}
          comments={comments}
          currentUser={currentUser}
          onAddComment={handleAddComment}
        />
      )}

      <Toaster position="top-right" richColors />
    </div>
  );
}
