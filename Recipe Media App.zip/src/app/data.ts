export interface User {
  id: number;
  username: string;
  email: string;
  password: string;
  fullName: string;
  initials: string;
  avatarColor: string;
}

export interface Category {
  id: number;
  name: string;
}

export interface Recipe {
  id: number;
  title: string;
  ingredients: string;
  instructions: string;
  categoryId: number;
  userId: number;
  imageUrl: string;
  createdAt: string;
}

export interface Comment {
  id: number;
  recipeId: number;
  userId: number;
  content: string;
  createdAt: string;
}

export const categories: Category[] = [
  { id: 1, name: "Breakfast" },
  { id: 2, name: "Dinner" },
  { id: 3, name: "Desserts" },
  { id: 4, name: "Drinks" },
  { id: 5, name: "Vegan" },
  { id: 6, name: "Snacks" },
  { id: 7, name: "Appetizers" },
  { id: 8, name: "Main Course" },
];

export const initialUsers: User[] = [
  {
    id: 1,
    username: "priya_sharma",
    email: "priya@example.com",
    password: "demo123",
    fullName: "Priya Sharma",
    initials: "PS",
    avatarColor: "#C2563C",
  },
  {
    id: 2,
    username: "raj_patel",
    email: "raj@example.com",
    password: "demo123",
    fullName: "Raj Patel",
    initials: "RP",
    avatarColor: "#F4A261",
  },
  {
    id: 3,
    username: "anita_kumar",
    email: "anita@example.com",
    password: "demo123",
    fullName: "Anita Kumar",
    initials: "AK",
    avatarColor: "#E9C46A",
  },
];

export const initialRecipes: Recipe[] = [
  {
    id: 1,
    title: "Butter Chicken",
    ingredients: "Chicken - 500g, Tomatoes - 4, Cream - 1 cup, Butter - 3 tbsp, Garam Masala - 2 tsp, Ginger-Garlic Paste - 2 tbsp, Kashmiri Red Chili - 1 tsp, Salt to taste",
    instructions: "1. Marinate chicken with yogurt, ginger-garlic paste, and spices for 30 minutes.\n2. Cook chicken in a pan until golden brown.\n3. Make gravy by cooking tomatoes, butter, and spices until smooth.\n4. Add cream and cooked chicken to the gravy.\n5. Simmer for 10 minutes and garnish with fresh cream.",
    categoryId: 8,
    userId: 1,
    imageUrl: "https://images.unsplash.com/photo-1714799263303-29e7d638578a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXR0ZXIlMjBjaGlja2VuJTIwaW5kaWFuJTIwZm9vZHxlbnwxfHx8fDE3NzY2OTAyNDV8MA&ixlib=rb-4.1.0&q=80&w=1080",
    createdAt: "2026-04-18T10:30:00Z",
  },
  {
    id: 2,
    title: "Masala Oats",
    ingredients: "Oats - 1 cup, Mixed Vegetables - 1 cup, Onion - 1, Tomato - 1, Green Chili - 2, Turmeric - 1/2 tsp, Cumin Seeds - 1 tsp, Salt to taste, Coriander leaves for garnish",
    instructions: "1. Heat oil in a pan and add cumin seeds.\n2. Add chopped onions, green chilies, and sauté until golden.\n3. Add mixed vegetables and cook for 5 minutes.\n4. Add turmeric, salt, and 2 cups of water.\n5. Once boiling, add oats and cook for 3-4 minutes.\n6. Garnish with coriander leaves and serve hot.",
    categoryId: 1,
    userId: 2,
    imageUrl: "https://images.unsplash.com/photo-1681150405668-cd5b2a37195d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvYXRzJTIwYnJlYWtmYXN0JTIwaGVhbHRoeXxlbnwxfHx8fDE3NzY2OTAyNDZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    createdAt: "2026-04-17T08:15:00Z",
  },
  {
    id: 3,
    title: "Mango Kulfi",
    ingredients: "Mango Pulp - 2 cups, Condensed Milk - 1 cup, Heavy Cream - 1 cup, Cardamom Powder - 1/2 tsp, Chopped Pistachios - 2 tbsp",
    instructions: "1. Mix mango pulp, condensed milk, and cream in a large bowl.\n2. Add cardamom powder and mix well.\n3. Pour into kulfi molds or small cups.\n4. Sprinkle chopped pistachios on top.\n5. Freeze for 6-8 hours or overnight.\n6. Serve chilled.",
    categoryId: 3,
    userId: 3,
    imageUrl: "https://images.unsplash.com/photo-1561087701-13705d0139ca?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYW5nbyUyMGt1bGZpJTIwaW5kaWFuJTIwZGVzc2VydHxlbnwxfHx8fDE3NzY2OTAyNDZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    createdAt: "2026-04-16T15:45:00Z",
  },
  {
    id: 4,
    title: "Palak Paneer",
    ingredients: "Spinach - 500g, Paneer - 250g, Onion - 2, Tomato - 2, Ginger-Garlic Paste - 1 tbsp, Cumin - 1 tsp, Garam Masala - 1 tsp, Cream - 3 tbsp, Oil - 2 tbsp, Salt to taste",
    instructions: "1. Blanch spinach in boiling water for 2 minutes, then blend into a smooth paste.\n2. Fry paneer cubes until golden and set aside.\n3. Sauté onions, ginger-garlic paste, and tomatoes until soft.\n4. Add spinach paste, cumin, garam masala, and salt.\n5. Cook for 5 minutes, then add cream and paneer.\n6. Simmer for 3-4 minutes and serve with naan or rice.",
    categoryId: 8,
    userId: 1,
    imageUrl: "https://images.unsplash.com/photo-1767114915936-745dd372f1d8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwyfHxwYWxhayUyMHBhbmVlciUyMHNwaW5hY2glMjBjdXJyeXxlbnwxfHx8fDE3NzY2OTAyNDd8MA&ixlib=rb-4.1.0&q=80&w=1080",
    createdAt: "2026-04-19T12:20:00Z",
  },
  {
    id: 5,
    title: "Rose Lassi",
    ingredients: "Yogurt - 2 cups, Rose Syrup - 3 tbsp, Milk - 1/2 cup, Sugar - 2 tbsp, Ice cubes - 1 cup, Rose petals for garnish",
    instructions: "1. Add yogurt, milk, rose syrup, and sugar to a blender.\n2. Blend until smooth and frothy.\n3. Add ice cubes and blend again.\n4. Pour into glasses and garnish with rose petals.\n5. Serve chilled immediately.",
    categoryId: 4,
    userId: 2,
    imageUrl: "https://images.unsplash.com/photo-1630409346699-79481a79db52?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYXNzaSUyMGluZGlhbiUyMGRyaW5rfGVufDF8fHx8MTc3NjY5MDI0N3ww&ixlib=rb-4.1.0&q=80&w=1080",
    createdAt: "2026-04-18T14:00:00Z",
  },
  {
    id: 6,
    title: "Samosa",
    ingredients: "All-purpose Flour - 2 cups, Potatoes - 4 (boiled & mashed), Peas - 1/2 cup, Cumin Seeds - 1 tsp, Garam Masala - 1 tsp, Coriander Powder - 1 tsp, Green Chili - 2, Oil for frying, Salt to taste",
    instructions: "1. Make dough with flour, salt, and water. Rest for 30 minutes.\n2. Prepare filling by sautéing cumin, green chili, peas, potatoes, and spices.\n3. Roll dough into thin circles and cut in half.\n4. Form cones and fill with potato mixture.\n5. Seal edges with water.\n6. Deep fry until golden brown and crispy.\n7. Serve hot with chutney.",
    categoryId: 6,
    userId: 3,
    imageUrl: "https://images.unsplash.com/photo-1697155836252-d7f969108b5a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYW1vc2ElMjBpbmRpYW4lMjBzbmFja3xlbnwxfHx8fDE3NzY2OTAyNDh8MA&ixlib=rb-4.1.0&q=80&w=1080",
    createdAt: "2026-04-19T09:30:00Z",
  },
];

export const initialComments: Comment[] = [
  {
    id: 1,
    recipeId: 1,
    userId: 2,
    content: "This is absolutely delicious! The perfect blend of spices. I made it for dinner last night and my family loved it!",
    createdAt: "2026-04-18T18:20:00Z",
  },
  {
    id: 2,
    recipeId: 1,
    userId: 3,
    content: "Great recipe! I added a bit more cream for extra richness. Highly recommend!",
    createdAt: "2026-04-19T10:15:00Z",
  },
  {
    id: 3,
    recipeId: 2,
    userId: 1,
    content: "Perfect for a healthy breakfast! Quick and easy to make.",
    createdAt: "2026-04-17T19:30:00Z",
  },
  {
    id: 4,
    recipeId: 3,
    userId: 1,
    content: "My kids absolutely love this! Best summer dessert ever.",
    createdAt: "2026-04-17T08:45:00Z",
  },
  {
    id: 5,
    recipeId: 5,
    userId: 3,
    content: "So refreshing! I love the rose flavor. Perfect for hot summer days!",
    createdAt: "2026-04-18T16:00:00Z",
  },
  {
    id: 6,
    recipeId: 6,
    userId: 1,
    content: "Crispy and delicious! Takes a bit of time but totally worth it.",
    createdAt: "2026-04-19T11:00:00Z",
  },
];

export const getInitials = (name: string): string => {
  const parts = name.trim().split(" ");
  if (parts.length >= 2) {
    return (parts[0][0] + parts[1][0]).toUpperCase();
  }
  return parts[0].substring(0, 2).toUpperCase();
};

export const getRandomColor = (): string => {
  const colors = ["#C2563C", "#F4A261", "#E9C46A", "#8B6F47", "#D4A574"];
  return colors[Math.floor(Math.random() * colors.length)];
};

export const loadFromLocalStorage = <T>(key: string, defaultValue: T): T => {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch (error) {
    return defaultValue;
  }
};

export const saveToLocalStorage = <T>(key: string, value: T): void => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error("Error saving to localStorage:", error);
  }
};
