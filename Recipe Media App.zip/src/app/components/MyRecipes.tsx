import { useState } from "react";
import { Recipe, User, Category, Comment } from "../data";
import RecipeCard from "./RecipeCard";
import RecipeModal from "./RecipeModal";
import { BookOpen } from "lucide-react";

interface MyRecipesProps {
  recipes: Recipe[];
  users: User[];
  categories: Category[];
  comments: Comment[];
  currentUser: User;
  onAddComment: (recipeId: number, content: string) => void;
}

export default function MyRecipes({
  recipes,
  users,
  categories,
  comments,
  currentUser,
  onAddComment,
}: MyRecipesProps) {
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);

  const myRecipes = recipes.filter((recipe) => recipe.userId === currentUser.id);

  const handleRecipeClick = (recipe: Recipe) => {
    setSelectedRecipe(recipe);
  };

  const handleCloseModal = () => {
    setSelectedRecipe(null);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-4xl mb-2" style={{ fontFamily: 'Playfair Display, serif' }}>
            My Recipes
          </h1>
          <p className="text-muted-foreground">
            Recipes you've shared with the community
          </p>
        </div>

        {myRecipes.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <BookOpen className="w-12 h-12 text-muted-foreground" />
            </div>
            <h3 className="text-xl mb-2">No recipes yet</h3>
            <p className="text-muted-foreground mb-6">
              Start sharing your culinary creations with the community
            </p>
          </div>
        ) : (
          <>
            <div className="mb-4 text-sm text-muted-foreground">
              You have shared {myRecipes.length} recipe{myRecipes.length !== 1 ? 's' : ''}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {myRecipes.map((recipe) => {
                const category = categories.find((c) => c.id === recipe.categoryId);
                if (!category) return null;

                return (
                  <RecipeCard
                    key={recipe.id}
                    recipe={recipe}
                    author={currentUser}
                    category={category}
                    onClick={() => handleRecipeClick(recipe)}
                  />
                );
              })}
            </div>
          </>
        )}
      </div>

      {selectedRecipe && (
        <RecipeModal
          recipe={selectedRecipe}
          author={currentUser}
          category={categories.find((c) => c.id === selectedRecipe.categoryId)!}
          comments={comments.filter((c) => c.recipeId === selectedRecipe.id)}
          users={users}
          currentUser={currentUser}
          onClose={handleCloseModal}
          onAddComment={onAddComment}
        />
      )}
    </div>
  );
}
