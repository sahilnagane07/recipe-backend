import { useState } from "react";
import { Category, User } from "../data";
import { ChefHat, ImagePlus } from "lucide-react";

interface AddRecipeProps {
  categories: Category[];
  currentUser: User;
  onAddRecipe: (recipe: {
    title: string;
    ingredients: string;
    instructions: string;
    categoryId: number;
    imageUrl: string;
  }) => void;
  onSuccess: () => void;
}

export default function AddRecipe({
  categories,
  currentUser,
  onAddRecipe,
  onSuccess,
}: AddRecipeProps) {
  const [title, setTitle] = useState("");
  const [ingredients, setIngredients] = useState("");
  const [instructions, setInstructions] = useState("");
  const [categoryId, setCategoryId] = useState<number>(categories[0]?.id || 1);
  const [imageUrl, setImageUrl] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const newErrors: Record<string, string> = {};

    if (!title.trim()) {
      newErrors.title = "Recipe title is required";
    }

    if (!ingredients.trim()) {
      newErrors.ingredients = "Ingredients are required";
    }

    if (!instructions.trim()) {
      newErrors.instructions = "Instructions are required";
    }

    if (!imageUrl.trim()) {
      newErrors.imageUrl = "Image URL is required";
    } else if (!imageUrl.startsWith("http")) {
      newErrors.imageUrl = "Please enter a valid URL";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validate()) {
      return;
    }

    onAddRecipe({
      title: title.trim(),
      ingredients: ingredients.trim(),
      instructions: instructions.trim(),
      categoryId,
      imageUrl: imageUrl.trim(),
    });

    setTitle("");
    setIngredients("");
    setInstructions("");
    setCategoryId(categories[0]?.id || 1);
    setImageUrl("");
    setErrors({});

    onSuccess();
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-4xl mb-2" style={{ fontFamily: 'Playfair Display, serif' }}>
            Add New Recipe
          </h1>
          <p className="text-muted-foreground">
            Share your culinary creation with the community
          </p>
        </div>

        <div className="bg-card rounded-xl border border-border p-6 md:p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block mb-2">Recipe Title *</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., Creamy Butter Chicken"
                className={`w-full px-4 py-3 rounded-lg border ${
                  errors.title ? "border-red-500" : "border-border"
                } bg-input-background focus:outline-none focus:ring-2 focus:ring-primary`}
              />
              {errors.title && (
                <p className="text-red-500 text-sm mt-1">{errors.title}</p>
              )}
            </div>

            <div>
              <label className="block mb-2">Category *</label>
              <select
                value={categoryId}
                onChange={(e) => setCategoryId(Number(e.target.value))}
                className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
              >
                {categories.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block mb-2">Image URL *</label>
              <div className="flex gap-3">
                <div className="flex-1">
                  <input
                    type="text"
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    placeholder="https://example.com/image.jpg"
                    className={`w-full px-4 py-3 rounded-lg border ${
                      errors.imageUrl ? "border-red-500" : "border-border"
                    } bg-input-background focus:outline-none focus:ring-2 focus:ring-primary`}
                  />
                  {errors.imageUrl && (
                    <p className="text-red-500 text-sm mt-1">{errors.imageUrl}</p>
                  )}
                </div>
                {imageUrl && imageUrl.startsWith("http") && (
                  <div className="w-24 h-24 rounded-lg overflow-hidden border border-border flex-shrink-0">
                    <img
                      src={imageUrl}
                      alt="Preview"
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        e.currentTarget.src = "";
                        e.currentTarget.alt = "Invalid image";
                      }}
                    />
                  </div>
                )}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Tip: You can use Unsplash.com for free food images
              </p>
            </div>

            <div>
              <label className="block mb-2">Ingredients *</label>
              <textarea
                value={ingredients}
                onChange={(e) => setIngredients(e.target.value)}
                placeholder="List ingredients separated by commas&#10;e.g., Chicken - 500g, Tomatoes - 4, Cream - 1 cup, Butter - 3 tbsp"
                rows={5}
                className={`w-full px-4 py-3 rounded-lg border ${
                  errors.ingredients ? "border-red-500" : "border-border"
                } bg-input-background focus:outline-none focus:ring-2 focus:ring-primary resize-none`}
              />
              {errors.ingredients && (
                <p className="text-red-500 text-sm mt-1">{errors.ingredients}</p>
              )}
              <p className="text-xs text-muted-foreground mt-1">
                Separate each ingredient with a comma
              </p>
            </div>

            <div>
              <label className="block mb-2">Instructions *</label>
              <textarea
                value={instructions}
                onChange={(e) => setInstructions(e.target.value)}
                placeholder="Write step-by-step instructions, one per line&#10;1. Marinate chicken with spices&#10;2. Cook until golden brown&#10;3. Add tomato gravy"
                rows={8}
                className={`w-full px-4 py-3 rounded-lg border ${
                  errors.instructions ? "border-red-500" : "border-border"
                } bg-input-background focus:outline-none focus:ring-2 focus:ring-primary resize-none`}
              />
              {errors.instructions && (
                <p className="text-red-500 text-sm mt-1">{errors.instructions}</p>
              )}
              <p className="text-xs text-muted-foreground mt-1">
                Write each step on a new line
              </p>
            </div>

            <div className="flex gap-3 pt-4">
              <button
                type="submit"
                className="flex-1 py-3 bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
              >
                <ChefHat className="w-5 h-5" />
                <span>Publish Recipe</span>
              </button>
            </div>
          </form>
        </div>

        <div className="mt-6 bg-accent/20 border border-accent rounded-lg p-4">
          <h3 className="mb-2">Tips for a great recipe:</h3>
          <ul className="text-sm space-y-1 text-muted-foreground">
            <li>• Use a clear, descriptive title</li>
            <li>• Include precise measurements for ingredients</li>
            <li>• Write detailed, easy-to-follow instructions</li>
            <li>• Add a high-quality image to make it appealing</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
