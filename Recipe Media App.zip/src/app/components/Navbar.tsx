import { ChefHat, LogOut, PlusCircle, Home, BookOpen } from "lucide-react";
import { User } from "../data";

interface NavbarProps {
  currentUser: User;
  onLogout: () => void;
  currentView: string;
  onNavigate: (view: string) => void;
}

export default function Navbar({ currentUser, onLogout, currentView, onNavigate }: NavbarProps) {
  return (
    <nav className="sticky top-0 z-50 bg-card border-b border-border shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => onNavigate("explore")}>
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <ChefHat className="w-6 h-6 text-primary-foreground" />
              </div>
              <span className="text-xl hidden sm:block" style={{ fontFamily: 'Playfair Display, serif' }}>
                Recipe Media
              </span>
            </div>

            <div className="hidden md:flex items-center gap-2">
              <button
                onClick={() => onNavigate("explore")}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                  currentView === "explore"
                    ? "bg-primary text-primary-foreground"
                    : "text-foreground hover:bg-muted"
                }`}
              >
                <Home className="w-4 h-4" />
                <span>Explore</span>
              </button>
              <button
                onClick={() => onNavigate("my-recipes")}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                  currentView === "my-recipes"
                    ? "bg-primary text-primary-foreground"
                    : "text-foreground hover:bg-muted"
                }`}
              >
                <BookOpen className="w-4 h-4" />
                <span>My Recipes</span>
              </button>
              <button
                onClick={() => onNavigate("add-recipe")}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                  currentView === "add-recipe"
                    ? "bg-primary text-primary-foreground"
                    : "text-foreground hover:bg-muted"
                }`}
              >
                <PlusCircle className="w-4 h-4" />
                <span>Add Recipe</span>
              </button>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center gap-3">
              <div
                className="w-10 h-10 rounded-full flex items-center justify-center text-white"
                style={{ backgroundColor: currentUser.avatarColor }}
              >
                {currentUser.initials}
              </div>
              <div className="hidden lg:block">
                <div className="text-sm">{currentUser.fullName}</div>
                <div className="text-xs text-muted-foreground">@{currentUser.username}</div>
              </div>
            </div>
            <button
              onClick={onLogout}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-muted hover:bg-muted/80 transition-colors text-sm"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">Logout</span>
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        <div className="md:hidden flex items-center gap-2 pb-3 overflow-x-auto">
          <button
            onClick={() => onNavigate("explore")}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap text-sm ${
              currentView === "explore"
                ? "bg-primary text-primary-foreground"
                : "text-foreground bg-muted"
            }`}
          >
            <Home className="w-4 h-4" />
            <span>Explore</span>
          </button>
          <button
            onClick={() => onNavigate("my-recipes")}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap text-sm ${
              currentView === "my-recipes"
                ? "bg-primary text-primary-foreground"
                : "text-foreground bg-muted"
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>My Recipes</span>
          </button>
          <button
            onClick={() => onNavigate("add-recipe")}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap text-sm ${
              currentView === "add-recipe"
                ? "bg-primary text-primary-foreground"
                : "text-foreground bg-muted"
            }`}
          >
            <PlusCircle className="w-4 h-4" />
            <span>Add Recipe</span>
          </button>
        </div>
      </div>
    </nav>
  );
}
