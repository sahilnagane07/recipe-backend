import { useState } from "react";
import { User } from "../data";
import { ChefHat, Lock, Mail } from "lucide-react";

interface LoginProps {
  onLogin: (user: User) => void;
  onSwitchToRegister: () => void;
  users: User[];
}

export default function Login({ onLogin, onSwitchToRegister, users }: LoginProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    const user = users.find(
      (u) => u.email === email && u.password === password
    );

    if (user) {
      onLogin(user);
    } else {
      setError("Invalid email or password");
    }
  };

  const fillDemoAccount = () => {
    setEmail("priya@example.com");
    setPassword("demo123");
  };

  return (
    <div className="min-h-screen flex">
      {/* Left Side - Login Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 bg-background">
        <div className="w-full max-w-md">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
              <ChefHat className="w-7 h-7 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-3xl" style={{ fontFamily: 'Playfair Display, serif' }}>Recipe Media</h1>
              <p className="text-sm text-muted-foreground">Share your culinary journey</p>
            </div>
          </div>

          <div className="mb-6">
            <h2 className="text-2xl mb-2" style={{ fontFamily: 'Playfair Display, serif' }}>Welcome Back</h2>
            <p className="text-muted-foreground">Sign in to explore and share recipes</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block mb-2 text-sm">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-11 pr-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="Enter your email"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block mb-2 text-sm">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-11 pr-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="Enter your password"
                  required
                />
              </div>
            </div>

            {error && (
              <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">
                {error}
              </div>
            )}

            <button
              type="submit"
              className="w-full py-3 bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition-opacity"
            >
              Sign In
            </button>
          </form>

          <div className="mt-6 p-4 bg-accent/20 rounded-lg border border-accent">
            <p className="text-sm mb-2">
              <span className="font-medium">Demo Account:</span> priya@example.com / demo123
            </p>
            <button
              onClick={fillDemoAccount}
              className="text-sm text-primary hover:underline"
            >
              Click to auto-fill
            </button>
          </div>

          <p className="mt-6 text-center text-sm text-muted-foreground">
            Don't have an account?{" "}
            <button
              onClick={onSwitchToRegister}
              className="text-primary hover:underline"
            >
              Create one
            </button>
          </p>
        </div>
      </div>

      {/* Right Side - Feature Highlights */}
      <div className="hidden lg:flex w-1/2 bg-gradient-to-br from-[#2D1810] via-[#4A2C1F] to-[#2D1810] p-12 flex-col justify-center text-white">
        <div className="max-w-lg">
          <h2 className="text-4xl mb-6" style={{ fontFamily: 'Playfair Display, serif' }}>
            Join Our Culinary Community
          </h2>
          <div className="space-y-6">
            <div className="flex gap-4">
              <div className="w-12 h-12 bg-white/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <ChefHat className="w-6 h-6" />
              </div>
              <div>
                <h3 className="mb-1">Share Your Recipes</h3>
                <p className="text-white/70 text-sm">Post your favorite dishes and inspire others</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-12 h-12 bg-white/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
              <div>
                <h3 className="mb-1">Discover New Flavors</h3>
                <p className="text-white/70 text-sm">Explore recipes from food enthusiasts worldwide</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-12 h-12 bg-white/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                </svg>
              </div>
              <div>
                <h3 className="mb-1">Engage & Learn</h3>
                <p className="text-white/70 text-sm">Comment, discuss, and learn from the community</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
