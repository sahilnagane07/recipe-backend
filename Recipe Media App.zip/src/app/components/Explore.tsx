import { useState } from "react";
import { Recipe, User, Category, Comment } from "../data";
import RecipeCard from "./RecipeCard";
import RecipeModal from "./RecipeModal";
import { Search } from "lucide-react";

interface ExploreProps {
  recipes: Recipe[];
  users: User[];
  categories: Category[];
  comments: Comment[];
  currentUser: User;
  onAddComment: (recipeId: number, content: string) => void;
}

export default function Explore({
  recipes,
  users,
  categories,
  comments,
  currentUser,
  onAddComment,
}: ExploreProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);

  const filteredRecipes = recipes.filter((recipe) => {
    const matchesSearch = recipe.title
      .toLowerCase()
      .includes(searchQuery.toLowerCase());
    const matchesCategory =
      selectedCategory === null || recipe.categoryId === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleRecipeClick = (recipe: Recipe) => {
    setSelectedRecipe(recipe);
  };

  const handleCloseModal = () => {
    setSelectedRecipe(null);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-4xl mb-2" style={{ fontFamily: 'Playfair Display, serif' }}>
            Explore Recipes
          </h1>
          <p className="text-muted-foreground">
            Discover delicious recipes from our community
          </p>
        </div>

        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search recipes by title..."
              className="w-full pl-12 pr-4 py-3 rounded-lg border border-border bg-card focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
        </div>

        <div className="mb-8 flex flex-wrap gap-2">
          <button
            onClick={() => setSelectedCategory(null)}
            className={`px-4 py-2 rounded-full transition-colors ${
              selectedCategory === null
                ? "bg-primary text-primary-foreground"
                : "bg-card border border-border hover:bg-muted"
            }`}
          >
            All Recipes
          </button>
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-4 py-2 rounded-full transition-colors ${
                selectedCategory === category.id
                  ? "bg-primary text-primary-foreground"
                  : "bg-card border border-border hover:bg-muted"
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>

        {filteredRecipes.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-12 h-12 text-muted-foreground" />
            </div>
            <h3 className="text-xl mb-2">No recipes found</h3>
            <p className="text-muted-foreground">
              Try adjusting your search or filter to find what you're looking for
            </p>
          </div>
        ) : (
          <>
            <div className="mb-4 text-sm text-muted-foreground">
              Showing {filteredRecipes.length} recipe{filteredRecipes.length !== 1 ? 's' : ''}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredRecipes.map((recipe) => {
                const author = users.find((u) => u.id === recipe.userId);
                const category = categories.find((c) => c.id === recipe.categoryId);
                if (!author || !category) return null;

                return (
                  <RecipeCard
                    key={recipe.id}
                    recipe={recipe}
                    author={author}
                    category={category}
                    onClick={() => handleRecipeClick(recipe)}
                  />
                );
              })}
            </div>
          </>
        )}
      </div>

      {selectedRecipe && (
        <RecipeModal
          recipe={selectedRecipe}
          author={users.find((u) => u.id === selectedRecipe.userId)!}
          category={categories.find((c) => c.id === selectedRecipe.categoryId)!}
          comments={comments.filter((c) => c.recipeId === selectedRecipe.id)}
          users={users}
          currentUser={currentUser}
          onClose={handleCloseModal}
          onAddComment={onAddComment}
        />
      )}
    </div>
  );
}
