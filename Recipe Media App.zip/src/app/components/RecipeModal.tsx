import { useState } from "react";
import { Recipe, User, Category, Comment } from "../data";
import { X, Clock, Send } from "lucide-react";

interface RecipeModalProps {
  recipe: Recipe;
  author: User;
  category: Category;
  comments: Comment[];
  users: User[];
  currentUser: User;
  onClose: () => void;
  onAddComment: (recipeId: number, content: string) => void;
}

export default function RecipeModal({
  recipe,
  author,
  category,
  comments,
  users,
  currentUser,
  onClose,
  onAddComment,
}: RecipeModalProps) {
  const [newComment, setNewComment] = useState("");

  const handleSubmitComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (newComment.trim()) {
      onAddComment(recipe.id, newComment.trim());
      setNewComment("");
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      />

      <div className="relative bg-card rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden shadow-2xl">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 w-10 h-10 bg-black/50 hover:bg-black/70 text-white rounded-full flex items-center justify-center transition-colors"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="overflow-y-auto max-h-[90vh]">
          <div className="aspect-[16/9] overflow-hidden bg-muted">
            <img
              src={recipe.imageUrl}
              alt={recipe.title}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="p-6 md:p-8">
            <div className="flex items-center gap-2 mb-4">
              <span className="px-4 py-1.5 bg-secondary/20 text-secondary-foreground rounded-full text-sm">
                {category.name}
              </span>
              <span className="flex items-center gap-1 text-sm text-muted-foreground">
                <Clock className="w-4 h-4" />
                {formatDate(recipe.createdAt)}
              </span>
            </div>

            <h2 className="text-3xl mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
              {recipe.title}
            </h2>

            <div className="flex items-center gap-3 mb-6 pb-6 border-b border-border">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center text-white"
                style={{ backgroundColor: author.avatarColor }}
              >
                {author.initials}
              </div>
              <div>
                <div>{author.fullName}</div>
                <div className="text-sm text-muted-foreground">@{author.username}</div>
              </div>
            </div>

            <div className="mb-6">
              <h3 className="text-xl mb-3" style={{ fontFamily: 'Playfair Display, serif' }}>
                Ingredients
              </h3>
              <div className="bg-muted/30 rounded-lg p-4">
                <ul className="space-y-2">
                  {recipe.ingredients.split(',').map((ingredient, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <span className="text-primary mt-1">•</span>
                      <span>{ingredient.trim()}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="mb-8">
              <h3 className="text-xl mb-3" style={{ fontFamily: 'Playfair Display, serif' }}>
                Instructions
              </h3>
              <div className="space-y-3">
                {recipe.instructions.split('\n').map((step, index) => (
                  <div key={index} className="flex gap-3">
                    {step.trim() && (
                      <>
                        <div className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center flex-shrink-0 text-sm">
                          {index + 1}
                        </div>
                        <p className="flex-1 pt-1">{step.trim().replace(/^\d+\.\s*/, '')}</p>
                      </>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="border-t border-border pt-6">
              <h3 className="text-xl mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
                Comments ({comments.length})
              </h3>

              <form onSubmit={handleSubmitComment} className="mb-6">
                <div className="flex gap-3">
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center text-white flex-shrink-0"
                    style={{ backgroundColor: currentUser.avatarColor }}
                  >
                    {currentUser.initials}
                  </div>
                  <div className="flex-1 flex gap-2">
                    <input
                      type="text"
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      placeholder="Add a comment..."
                      className="flex-1 px-4 py-2 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                    <button
                      type="submit"
                      disabled={!newComment.trim()}
                      className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Send className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </form>

              <div className="space-y-4">
                {comments.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">
                    No comments yet. Be the first to share your thoughts!
                  </p>
                ) : (
                  comments.map((comment) => {
                    const commentAuthor = users.find((u) => u.id === comment.userId);
                    if (!commentAuthor) return null;

                    return (
                      <div key={comment.id} className="flex gap-3">
                        <div
                          className="w-10 h-10 rounded-full flex items-center justify-center text-white flex-shrink-0"
                          style={{ backgroundColor: commentAuthor.avatarColor }}
                        >
                          {commentAuthor.initials}
                        </div>
                        <div className="flex-1 bg-muted/30 rounded-lg p-4">
                          <div className="flex items-center gap-2 mb-1">
                            <span>{commentAuthor.fullName}</span>
                            <span className="text-xs text-muted-foreground">
                              {formatDate(comment.createdAt)}
                            </span>
                          </div>
                          <p className="text-sm">{comment.content}</p>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
