import { Recipe, User, Category } from "../data";
import { Clock, User as UserIcon } from "lucide-react";

interface RecipeCardProps {
  recipe: Recipe;
  author: User;
  category: Category;
  onClick: () => void;
}

export default function RecipeCard({ recipe, author, category, onClick }: RecipeCardProps) {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));

    if (diffInHours < 24) {
      return `${diffInHours}h ago`;
    } else if (diffInHours < 48) {
      return "Yesterday";
    } else {
      const days = Math.floor(diffInHours / 24);
      return `${days} days ago`;
    }
  };

  return (
    <div
      onClick={onClick}
      className="group cursor-pointer bg-card rounded-xl overflow-hidden border border-border hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
    >
      <div className="aspect-[4/3] overflow-hidden bg-muted">
        <img
          src={recipe.imageUrl}
          alt={recipe.title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
      </div>

      <div className="p-4">
        <div className="flex items-center gap-2 mb-2">
          <span className="px-3 py-1 bg-secondary/20 text-secondary-foreground rounded-full text-xs">
            {category.name}
          </span>
          <span className="flex items-center gap-1 text-xs text-muted-foreground">
            <Clock className="w-3 h-3" />
            {formatDate(recipe.createdAt)}
          </span>
        </div>

        <h3 className="text-lg mb-2 line-clamp-1" style={{ fontFamily: 'Playfair Display, serif' }}>
          {recipe.title}
        </h3>

        <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
          {recipe.ingredients.split(',').slice(0, 3).join(', ')}...
        </p>

        <div className="flex items-center gap-2 pt-3 border-t border-border">
          <div
            className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs"
            style={{ backgroundColor: author.avatarColor }}
          >
            {author.initials}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm truncate">{author.fullName}</div>
            <div className="text-xs text-muted-foreground truncate">@{author.username}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
